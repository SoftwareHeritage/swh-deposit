.. _swh-deposit:

Software Heritage - Deposit
===========================

Push-based deposit of software source code artifacts to the archive.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   getting-started.rst
   spec-api.rst
   metadata.rst
   dev-info.rst
   sys-info.rst
   specs/specs.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
