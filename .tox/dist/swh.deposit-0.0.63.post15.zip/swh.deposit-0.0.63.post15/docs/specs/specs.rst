.. _swh-deposit-specs:

Blueprint Specifications
=========================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   blueprint.rst
   spec-loading.rst
   spec-sparse-deposit.rst
   spec-meta-deposit.rst
